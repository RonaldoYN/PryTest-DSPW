CREATE DATABASE IF NOT EXISTS gestion_devoluciones;
USE gestion_devoluciones;

-- ========================================================
-- 1. CREACIÓN DE ESTRUCTURAS DE TABLAS
-- ========================================================

CREATE TABLE cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(100) NOT NULL,
  apellidos VARCHAR(100) NOT NULL,
  correo VARCHAR(100) DEFAULT NULL,
  telefono VARCHAR(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE personal (
  id_personal INT AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(100) NOT NULL,
  apellidos VARCHAR(100) NOT NULL,
  dni VARCHAR(8) DEFAULT NULL,
  correo VARCHAR(100) DEFAULT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol VARCHAR(30) DEFAULT 'Personal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE prenda (
  id_prenda INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  categoria VARCHAR(50) DEFAULT NULL,
  talla VARCHAR(10) DEFAULT NULL,
  color VARCHAR(30) DEFAULT NULL,
  precio DECIMAL(10,2) DEFAULT NULL,
  stock INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE estado_devolucion (
  id_estado INT AUTO_INCREMENT PRIMARY KEY,
  nombre_estado VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE motivo_devolucion (
  id_motivo INT AUTO_INCREMENT PRIMARY KEY,
  descripcion VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE devolucion (
  id_devolucion INT AUTO_INCREMENT PRIMARY KEY,
  fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
  observacion TEXT DEFAULT NULL,
  id_cliente INT NOT NULL,
  id_personal INT NOT NULL,
  id_estado INT NOT NULL,
  id_motivo INT NOT NULL,
  FOREIGN KEY (id_cliente) REFERENCES cliente (id_cliente),
  FOREIGN KEY (id_personal) REFERENCES personal (id_personal),
  FOREIGN KEY (id_estado) REFERENCES estado_devolucion (id_estado),
  FOREIGN KEY (id_motivo) REFERENCES motivo_devolucion (id_motivo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE detalle_devolucion (
  id_detalle INT AUTO_INCREMENT PRIMARY KEY,
  id_devolucion INT NOT NULL,
  id_prenda INT NOT NULL,
  cantidad INT NOT NULL,
  observacion VARCHAR(200) DEFAULT NULL,
  FOREIGN KEY (id_devolucion) REFERENCES devolucion (id_devolucion),
  FOREIGN KEY (id_prenda) REFERENCES prenda (id_prenda)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ========================================================
-- 2. INSERCIÓN DE DATOS INICIALES (SEMILLAS)
-- ========================================================

INSERT INTO estado_devolucion (id_estado, nombre_estado) VALUES
(1, 'Pendiente'),
(2, 'En Evaluacion'),
(3, 'Aprobada'),
(4, 'Rechazada');

INSERT INTO motivo_devolucion (id_motivo, descripcion) VALUES
(1, 'Talla incorrecta'),
(2, 'Producto defectuoso'),
(3, 'No era lo esperado'),
(4, 'Error en el pedido'),
(5, 'Cambio de preferencia');

INSERT INTO personal (id_personal, nombres, apellidos, dni, correo, username, password, rol) VALUES
(1, 'Personal', 'Prueba', '12345678', 'personal@shop.pe', 'PersonalP', 'personalprueba', 'Personal'),
(2, 'Ronaldo', 'Nunez', '73192930', 'rnv@shop.pe', 'RYNV', '123456', 'Administrador');

INSERT INTO cliente (id_cliente, nombres, apellidos, correo, telefono) VALUES
(1, 'Carlos', 'Mendoza Ruiz', 'carlos.mendoza@email.com', '987654321'),
(2, 'María', 'Delgado Silva', 'maria.delgado@email.com', '912345678'),
(3, 'Luis', 'Sánchez Quispe', 'luis.sanchez@email.com', '955666777');

INSERT INTO prenda (id_prenda, nombre, categoria, talla, color, precio, stock) VALUES
(1, 'Casaca Jean Clásica', 'Casacas', 'M', 'Azul', 149.90, 20),
(2, 'Pantalón Chino Slim', 'Pantalones', '32', 'Beige', 99.00, 15),
(3, 'Polo Oversized Algodón', 'Polos', 'L', 'Negro', 59.90, 40),
(4, 'Blusa Floral Primavera', 'Blusas', 'S', 'Blanco', 79.50, 12);

INSERT INTO devolucion (id_devolucion, fecha_solicitud, observacion, id_cliente, id_personal, id_estado, id_motivo) VALUES
(1, '2026-06-07 20:05:54', 'El cliente solicita cambio por una talla L', 1, 2, 1, 1);

INSERT INTO detalle_devolucion (id_detalle, id_devolucion, id_prenda, cantidad, observacion) VALUES
(1, 1, 1, 1, 'Empaque original intacto');

-- ========================================================
-- 3. PROCEDIMIENTOS ALMACENADOS
-- ========================================================

DELIMITER $$

CREATE PROCEDURE sp_BuscarCliente (IN p_criterio VARCHAR(100))
BEGIN
    SELECT id_cliente, nombres, apellidos, correo, telefono 
    FROM cliente
    WHERE apellidos LIKE CONCAT('%', p_criterio, '%') 
       OR nombres LIKE CONCAT('%', p_criterio, '%');
END$$

CREATE PROCEDURE sp_BuscarPersonal (IN p_criterio VARCHAR(100))
BEGIN
    SELECT id_personal, nombres, apellidos, dni, correo, username, rol 
    FROM personal
    WHERE apellidos LIKE CONCAT('%', p_criterio, '%') 
       OR dni LIKE CONCAT('%', p_criterio, '%');
END$$

CREATE PROCEDURE sp_BuscarPrenda (IN p_criterio VARCHAR(100))
BEGIN
    SELECT id_prenda, nombre, categoria, talla, color, precio, stock 
    FROM prenda
    WHERE nombre LIKE CONCAT('%', p_criterio, '%') 
       OR categoria LIKE CONCAT('%', p_criterio, '%');
END$$

CREATE PROCEDURE sp_CargarEstados ()
BEGIN
    SELECT id_estado, nombre_estado FROM estado_devolucion;
END$$

CREATE PROCEDURE sp_CargarMotivos ()
BEGIN
    SELECT id_motivo, descripcion FROM motivo_devolucion;
END$$

CREATE PROCEDURE sp_EliminarCliente (IN p_id INT)
BEGIN
    DELETE FROM cliente WHERE id_cliente = p_id;
END$$

CREATE PROCEDURE sp_EliminarPersonal (IN p_id INT)
BEGIN
    DELETE FROM personal WHERE id_personal = p_id;
END$$

CREATE PROCEDURE sp_EliminarPrenda (IN p_id INT)
BEGIN
    DELETE FROM prenda WHERE id_prenda = p_id;
END$$

CREATE PROCEDURE sp_InsertarCliente (IN p_nombres VARCHAR(100), IN p_apellidos VARCHAR(100), IN p_correo VARCHAR(100), IN p_telefono VARCHAR(20))
BEGIN
    INSERT INTO cliente (nombres, apellidos, correo, telefono)
    VALUES (p_nombres, p_apellidos, p_correo, p_telefono);
END$$

CREATE PROCEDURE sp_InsertarPersonal (IN p_nombres VARCHAR(100), IN p_apellidos VARCHAR(100), IN p_dni VARCHAR(8), IN p_correo VARCHAR(100), IN p_username VARCHAR(50), IN p_password VARCHAR(255), IN p_rol VARCHAR(30))
BEGIN
    INSERT INTO personal (nombres, apellidos, dni, correo, username, `password`, rol)
    VALUES (p_nombres, p_apellidos, p_dni, p_correo, p_username, p_password, p_rol);
END$$

CREATE PROCEDURE sp_InsertarPrenda (IN p_nombre VARCHAR(100), IN p_categoria VARCHAR(50), IN p_talla VARCHAR(10), IN p_color VARCHAR(30), IN p_precio DECIMAL(10,2), IN p_stock INT)
BEGIN
    INSERT INTO prenda (nombre, categoria, talla, color, precio, stock)
    VALUES (p_nombre, p_categoria, p_talla, p_color, p_precio, p_stock);
END$$

CREATE PROCEDURE sp_ListarClientes ()
BEGIN
    SELECT id_cliente, nombres, apellidos, correo, telefono FROM cliente;
END$$

CREATE PROCEDURE sp_ListarGestionDevoluciones ()
BEGIN
    SELECT 
        d.id_devolucion AS 'Nro Solicitud',
        d.fecha_solicitud AS 'Fecha',
        CONCAT(c.nombres, ' ', c.apellidos) AS 'Cliente',
        CONCAT(p.nombres, ' ', p.apellidos) AS 'Atendido Por',
        m.descripcion AS 'Motivo',
        e.nombre_estado AS 'Estado Actual',
        d.observacion AS 'Observaciones General'
    FROM devolucion d
    INNER JOIN cliente c ON d.id_cliente = c.id_cliente
    INNER JOIN personal p ON d.id_personal = p.id_personal
    INNER JOIN motivo_devolucion m ON d.id_motivo = m.id_motivo
    INNER JOIN estado_devolucion e ON d.id_estado = e.id_estado
    ORDER BY d.fecha_solicitud DESC;
END$$

CREATE PROCEDURE sp_ListarPersonal ()
BEGIN
    SELECT id_personal, nombres, apellidos, dni, correo, username, `password`, rol 
    FROM personal;
END$$

CREATE PROCEDURE sp_ListarPrendas ()
BEGIN
    SELECT id_prenda, nombre, categoria, talla, color, precio, stock FROM prenda;
END$$

CREATE PROCEDURE sp_ModificarCliente (IN p_id INT, IN p_nombres VARCHAR(100), IN p_apellidos VARCHAR(100), IN p_correo VARCHAR(100), IN p_telefono VARCHAR(20))
BEGIN
    UPDATE cliente 
    SET nombres = p_nombres, apellidos = p_apellidos, correo = p_correo, telefono = p_telefono
    WHERE id_cliente = p_id;
END$$

CREATE PROCEDURE sp_ModificarPersonal (IN p_id INT, IN p_nombres VARCHAR(100), IN p_apellidos VARCHAR(100), IN p_dni VARCHAR(8), IN p_correo VARCHAR(100), IN p_username VARCHAR(50), IN p_password VARCHAR(255), IN p_rol VARCHAR(30))
BEGIN
    UPDATE personal 
    SET nombres = p_nombres, apellidos = p_apellidos, dni = p_dni, 
        correo = p_correo, username = p_username, `password` = p_password, rol = p_rol
    WHERE id_personal = p_id;
END$$

CREATE PROCEDURE sp_ModificarPrenda (IN p_id INT, IN p_nombre VARCHAR(100), IN p_categoria VARCHAR(50), IN p_talla VARCHAR(10), IN p_color VARCHAR(30), IN p_precio DECIMAL(10,2), IN p_stock INT)
BEGIN
    UPDATE prenda 
    SET nombre = p_nombre, categoria = p_categoria, talla = p_talla, 
        color = p_color, precio = p_precio, stock = p_stock
    WHERE id_prenda = p_id;
END$$

CREATE PROCEDURE sp_ReporteMotivosComunes ()
BEGIN
    SELECT m.descripcion AS Motivo, COUNT(d.id_devolucion) AS Total
    FROM devolucion d
    INNER JOIN motivo_devolucion m ON d.id_motivo = m.id_motivo
    GROUP BY m.descripcion
    ORDER BY Total DESC;
END$$

CREATE PROCEDURE sp_ReportePrendasPorCategoria ()
BEGIN
    SELECT p.categoria, SUM(dd.cantidad) AS 'Prendas Devueltas'
    FROM detalle_devolucion dd
    INNER JOIN prenda p ON dd.id_prenda = p.id_prenda
    GROUP BY p.categoria;
END$$

CREATE PROCEDURE sp_ValidarLogin (IN p_username VARCHAR(50), IN p_password VARCHAR(255))
BEGIN
    SELECT id_personal, nombres, apellidos, rol 
    FROM personal 
    WHERE username = p_username AND `password` = p_password;
END$$

DELIMITER ;