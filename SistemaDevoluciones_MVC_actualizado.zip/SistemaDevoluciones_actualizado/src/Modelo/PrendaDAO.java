package Modelo;
/**
 * @author Usuario
 */
import Conexion.Conexion;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class PrendaDAO {

    // LISTAR O BUSCAR
    public DefaultTableModel listarPrendas(String criterio) {
        String[] titulos = {"Código", "Nombre", "Categoría", "Talla", "Color", "Precio", "Stock"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, titulos);
        
        String sql = criterio.isEmpty() ? "{CALL sp_ListarPrendas()}" : "{CALL sp_BuscarPrenda(?)}";
        
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            
            if (!criterio.isEmpty()) cst.setString(1, criterio);
            
            try (ResultSet rs = cst.executeQuery()) {
                Object[] fila = new Object[7];
                while (rs.next()) {
                    fila[0] = rs.getInt("id_prenda");
                    fila[1] = rs.getString("nombre");
                    fila[2] = rs.getString("categoria");
                    fila[3] = rs.getString("talla");
                    fila[4] = rs.getString("color");
                    fila[5] = rs.getDouble("precio");
                    fila[6] = rs.getInt("stock");
                    modeloTabla.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en PrendaDAO al listar: " + e.getMessage());
        }
        return modeloTabla;
    }

    // REGISTRAR
    public boolean insertar(String nombre, String cat, String talla, String color, double precio, int stock) {
        String sql = "{CALL sp_InsertarPrenda(?, ?, ?, ?, ?, ?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setString(1, nombre);
            cst.setString(2, cat);
            cst.setString(3, talla);
            cst.setString(4, color);
            cst.setDouble(5, precio);
            cst.setInt(6, stock);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar prenda: " + e.getMessage());
            return false;
        }
    }

    // MODIFICAR
    public boolean modificar(int id, String nombre, String cat, String talla, String color, double precio, int stock) {
        String sql = "{CALL sp_ModificarPrenda(?, ?, ?, ?, ?, ?, ?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setInt(1, id);
            cst.setString(2, nombre);
            cst.setString(3, cat);
            cst.setString(4, talla);
            cst.setString(5, color);
            cst.setDouble(6, precio);
            cst.setInt(7, stock);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al modificar prenda: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        String sql = "{CALL sp_EliminarPrenda(?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setInt(1, id);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar prenda: " + e.getMessage());
            return false;
        }
    }
}