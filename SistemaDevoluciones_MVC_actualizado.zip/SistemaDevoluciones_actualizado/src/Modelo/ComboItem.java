package Modelo;

/**
 * Elemento reutilizable para mostrar texto en un JComboBox,
 * pero conservar internamente el id de la base de datos.
 */
public class ComboItem {
    private final int id;
    private final String texto;

    public ComboItem(int id, String texto) {
        this.id = id;
        this.texto = texto;
    }

    public int getId() {
        return id;
    }

    public String getTexto() {
        return texto;
    }

    @Override
    public String toString() {
        return texto;
    }
}
