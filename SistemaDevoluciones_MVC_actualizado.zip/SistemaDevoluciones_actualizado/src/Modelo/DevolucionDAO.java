package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class DevolucionDAO {

    public List<ComboItem> cargarClientes() {
        List<ComboItem> lista = new ArrayList<>();
        String sql = "SELECT id_cliente, CONCAT(nombres, ' ', apellidos) AS cliente FROM cliente ORDER BY apellidos, nombres";

        try (Connection cn = Conexion.conectar();
             PreparedStatement pst = cn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                lista.add(new ComboItem(rs.getInt("id_cliente"), rs.getString("cliente")));
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar clientes: " + e.getMessage());
        }
        return lista;
    }

    public List<ComboItem> cargarPersonal() {
        List<ComboItem> lista = new ArrayList<>();
        String sql = "SELECT id_personal, CONCAT(nombres, ' ', apellidos, ' - ', rol) AS personal FROM personal ORDER BY apellidos, nombres";

        try (Connection cn = Conexion.conectar();
             PreparedStatement pst = cn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                lista.add(new ComboItem(rs.getInt("id_personal"), rs.getString("personal")));
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar personal: " + e.getMessage());
        }
        return lista;
    }

    public List<ComboItem> cargarPrendas() {
        List<ComboItem> lista = new ArrayList<>();
        String sql = "SELECT id_prenda, CONCAT(nombre, ' | Talla: ', IFNULL(talla,''), ' | Stock: ', stock) AS prenda FROM prenda ORDER BY nombre";

        try (Connection cn = Conexion.conectar();
             PreparedStatement pst = cn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                lista.add(new ComboItem(rs.getInt("id_prenda"), rs.getString("prenda")));
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar prendas: " + e.getMessage());
        }
        return lista;
    }

    public List<ComboItem> cargarEstados() {
        List<ComboItem> lista = new ArrayList<>();
        String sql = "{CALL sp_CargarEstados()}";

        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql);
             ResultSet rs = cst.executeQuery()) {

            while (rs.next()) {
                lista.add(new ComboItem(rs.getInt("id_estado"), rs.getString("nombre_estado")));
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar estados: " + e.getMessage());
        }
        return lista;
    }

    public List<ComboItem> cargarMotivos() {
        List<ComboItem> lista = new ArrayList<>();
        String sql = "{CALL sp_CargarMotivos()}";

        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql);
             ResultSet rs = cst.executeQuery()) {

            while (rs.next()) {
                lista.add(new ComboItem(rs.getInt("id_motivo"), rs.getString("descripcion")));
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar motivos: " + e.getMessage());
        }
        return lista;
    }

    public boolean registrarDevolucion(int idCliente, int idPersonal, int idEstado, int idMotivo,
            String observacionGeneral, int idPrenda, int cantidad, String observacionDetalle) {

        String sqlDevolucion = "INSERT INTO devolucion (observacion, id_cliente, id_personal, id_estado, id_motivo) "
                + "VALUES (?, ?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO detalle_devolucion (id_devolucion, id_prenda, cantidad, observacion) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection cn = Conexion.conectar()) {
            if (cn == null) {
                return false;
            }

            cn.setAutoCommit(false);

            try (PreparedStatement pstDev = cn.prepareStatement(sqlDevolucion, Statement.RETURN_GENERATED_KEYS)) {
                pstDev.setString(1, observacionGeneral);
                pstDev.setInt(2, idCliente);
                pstDev.setInt(3, idPersonal);
                pstDev.setInt(4, idEstado);
                pstDev.setInt(5, idMotivo);
                pstDev.executeUpdate();

                int idDevolucion;
                try (ResultSet rs = pstDev.getGeneratedKeys()) {
                    if (!rs.next()) {
                        cn.rollback();
                        return false;
                    }
                    idDevolucion = rs.getInt(1);
                }

                try (PreparedStatement pstDet = cn.prepareStatement(sqlDetalle)) {
                    pstDet.setInt(1, idDevolucion);
                    pstDet.setInt(2, idPrenda);
                    pstDet.setInt(3, cantidad);
                    pstDet.setString(4, observacionDetalle);
                    pstDet.executeUpdate();
                }

                cn.commit();
                return true;
            } catch (SQLException e) {
                cn.rollback();
                System.out.println("Error al registrar devolución: " + e.getMessage());
                return false;
            } finally {
                cn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.out.println("Error de transacción en devolución: " + e.getMessage());
            return false;
        }
    }

    public DefaultTableModel listarGestionDevoluciones(String criterio) {
        String[] titulos = {"ID", "Fecha", "Cliente", "Atendido por", "Motivo", "Estado", "Observación"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = "SELECT d.id_devolucion, d.fecha_solicitud, "
                + "CONCAT(c.nombres, ' ', c.apellidos) AS cliente, "
                + "CONCAT(p.nombres, ' ', p.apellidos) AS personal, "
                + "m.descripcion AS motivo, e.nombre_estado AS estado, d.observacion "
                + "FROM devolucion d "
                + "INNER JOIN cliente c ON d.id_cliente = c.id_cliente "
                + "INNER JOIN personal p ON d.id_personal = p.id_personal "
                + "INNER JOIN motivo_devolucion m ON d.id_motivo = m.id_motivo "
                + "INNER JOIN estado_devolucion e ON d.id_estado = e.id_estado "
                + "WHERE CONCAT(c.nombres, ' ', c.apellidos, ' ', m.descripcion, ' ', e.nombre_estado, ' ', d.id_devolucion) LIKE ? "
                + "ORDER BY d.fecha_solicitud DESC";

        try (Connection cn = Conexion.conectar();
             PreparedStatement pst = cn.prepareStatement(sql)) {

            pst.setString(1, "%" + criterio + "%");
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Object[] fila = new Object[7];
                    fila[0] = rs.getInt("id_devolucion");
                    fila[1] = rs.getTimestamp("fecha_solicitud");
                    fila[2] = rs.getString("cliente");
                    fila[3] = rs.getString("personal");
                    fila[4] = rs.getString("motivo");
                    fila[5] = rs.getString("estado");
                    fila[6] = rs.getString("observacion");
                    modelo.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al listar devoluciones: " + e.getMessage());
        }
        return modelo;
    }

    public DefaultTableModel listarDetalleDevolucion(int idDevolucion) {
        String[] titulos = {"Prenda", "Categoría", "Talla", "Color", "Cantidad", "Observación"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = "SELECT pr.nombre, pr.categoria, pr.talla, pr.color, dd.cantidad, dd.observacion "
                + "FROM detalle_devolucion dd "
                + "INNER JOIN prenda pr ON dd.id_prenda = pr.id_prenda "
                + "WHERE dd.id_devolucion = ?";

        try (Connection cn = Conexion.conectar();
             PreparedStatement pst = cn.prepareStatement(sql)) {

            pst.setInt(1, idDevolucion);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Object[] fila = new Object[6];
                    fila[0] = rs.getString("nombre");
                    fila[1] = rs.getString("categoria");
                    fila[2] = rs.getString("talla");
                    fila[3] = rs.getString("color");
                    fila[4] = rs.getInt("cantidad");
                    fila[5] = rs.getString("observacion");
                    modelo.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al listar detalle de devolución: " + e.getMessage());
        }
        return modelo;
    }

    public boolean actualizarEstado(int idDevolucion, int idEstado, String observacion) {
        String sql = "UPDATE devolucion SET id_estado = ?, observacion = ? WHERE id_devolucion = ?";

        try (Connection cn = Conexion.conectar();
             PreparedStatement pst = cn.prepareStatement(sql)) {

            pst.setInt(1, idEstado);
            pst.setString(2, observacion);
            pst.setInt(3, idDevolucion);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar estado de devolución: " + e.getMessage());
            return false;
        }
    }

    public DefaultTableModel reporteMotivosComunes() {
        String[] titulos = {"Motivo", "Total"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        String sql = "{CALL sp_ReporteMotivosComunes()}";

        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql);
             ResultSet rs = cst.executeQuery()) {

            while (rs.next()) {
                modelo.addRow(new Object[]{rs.getString("Motivo"), rs.getInt("Total")});
            }
        } catch (SQLException e) {
            System.out.println("Error en reporte de motivos: " + e.getMessage());
        }
        return modelo;
    }

    public DefaultTableModel reportePrendasPorCategoria() {
        String[] titulos = {"Categoría", "Prendas devueltas"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        String sql = "{CALL sp_ReportePrendasPorCategoria()}";

        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql);
             ResultSet rs = cst.executeQuery()) {

            while (rs.next()) {
                modelo.addRow(new Object[]{rs.getString("categoria"), rs.getInt("Prendas Devueltas")});
            }
        } catch (SQLException e) {
            System.out.println("Error en reporte de prendas por categoría: " + e.getMessage());
        }
        return modelo;
    }
}
