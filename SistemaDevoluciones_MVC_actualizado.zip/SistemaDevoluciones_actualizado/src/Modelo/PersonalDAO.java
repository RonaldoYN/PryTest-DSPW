package Modelo;
/**
 * @author RYNV
 */
import Conexion.Conexion;
import java.sql.*;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class PersonalDAO {
    
    // Ahora el método devuelve el ROL del usuario (ej: "Administrador", "Personal")
    // Si las credenciales son incorrectas, devolverá null.
    public String validarLogin(String username, String password) {
        String rol = null;
        
        // Asumiendo que tu SP en MySQL selecciona las columnas necesarias
        // Asegúrate de que tu sp_ValidarLogin devuelva una fila con la columna 'rol'
        String sql = "{CALL sp_ValidarLogin(?, ?)}";
        
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            
            cst.setString(1, username);
            cst.setString(2, password);
            
            try (ResultSet rs = cst.executeQuery()) {
                if (rs.next()) {
                    // Extraemos el rol directamente de la base de datos
                    rol = rs.getString("rol");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error crítico en UsuarioDAO: " + e.getMessage());
        }
        return rol;
    }
    
    // LISTAR O BUSCAR
    public DefaultTableModel listarPersonal(String criterio) {
        String[] titulos = {"Código", "Nombres", "Apellidos", "DNI", "Correo", "Usuario", "Rol"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, titulos);
        
        String sql = criterio.isEmpty() ? "{CALL sp_ListarPersonal()}" : "{CALL sp_BuscarPersonal(?)}";
        
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            
            if (!criterio.isEmpty()) cst.setString(1, criterio);
            
            try (ResultSet rs = cst.executeQuery()) {
                Object[] fila = new Object[7];
                while (rs.next()) {
                    fila[0] = rs.getInt("id_personal");
                    fila[1] = rs.getString("nombres");
                    fila[2] = rs.getString("apellidos");
                    fila[3] = rs.getString("dni");
                    fila[4] = rs.getString("correo");
                    fila[5] = rs.getString("username");
                    fila[6] = rs.getString("rol"); // sp_ListarPersonal debe tener el campo rol seleccionado
                    modeloTabla.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en PersonalDAO al listar: " + e.getMessage());
        }
        return modeloTabla;
    }

    // REGISTRAR
    public boolean insertar(String nom, String ape, String dni, String correo, String user, String pass, String rol) {
        String sql = "{CALL sp_InsertarPersonal(?, ?, ?, ?, ?, ?, ?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setString(1, nom);
            cst.setString(2, ape);
            cst.setString(3, dni);
            cst.setString(4, correo);
            cst.setString(5, user);
            cst.setString(6, pass);
            cst.setString(7, rol);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar personal: " + e.getMessage());
            return false;
        }
    }

    // MODIFICAR
    public boolean modificar(int id, String nom, String ape, String dni, String correo, String user, String pass, String rol) {
        String sql = "{CALL sp_ModificarPersonal(?, ?, ?, ?, ?, ?, ?, ?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setInt(1, id);
            cst.setString(2, nom);
            cst.setString(3, ape);
            cst.setString(4, dni);
            cst.setString(5, correo);
            cst.setString(6, user);
            cst.setString(7, pass);
            cst.setString(8, rol);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al modificar personal: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        String sql = "{CALL sp_EliminarPersonal(?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setInt(1, id);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar personal: " + e.getMessage());
            return false;
        }
    }
}
