package Modelo;

/**
 *
 * @author RYNV
 */
import Conexion.Conexion;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class ClienteDAO {

    // 1. LISTAR O BUSCAR CLIENTES EN LA TABLA
    public DefaultTableModel listarClientes(String criterio) {
        String[] titulos = {"Código", "Nombres", "Apellidos", "Correo", "Teléfono"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, titulos);
        
        // Si el criterio está vacío usa el SP de listar general, si tiene texto usa el SP de buscar
        String sql = criterio.isEmpty() ? "{CALL sp_ListarClientes()}" : "{CALL sp_BuscarCliente(?)}";
        
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            
            if (!criterio.isEmpty()) {
                cst.setString(1, criterio);
            }
            
            try (ResultSet rs = cst.executeQuery()) {
                Object[] fila = new Object[5];
                while (rs.next()) {
                    fila[0] = rs.getInt("id_cliente");
                    fila[1] = rs.getString("nombres");
                    fila[2] = rs.getString("apellidos");
                    fila[3] = rs.getString("correo");
                    fila[4] = rs.getString("telefono");
                    modeloTabla.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en ClienteDAO al listar: " + e.getMessage());
        }
        return modeloTabla;
    }

    // 2. REGISTRAR CLIENTE
    public boolean insertar(String nombres, String apellidos, String correo, String telefono) {
        String sql = "{CALL sp_InsertarCliente(?, ?, ?, ?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setString(1, nombres);
            cst.setString(2, apellidos);
            cst.setString(3, correo);
            cst.setString(4, telefono);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error en ClienteDAO al insertar: " + e.getMessage());
            return false;
        }
    }

    // 3. MODIFICAR CLIENTE
    public boolean modificar(int id, String nombres, String apellidos, String correo, String telefono) {
        String sql = "{CALL sp_ModificarCliente(?, ?, ?, ?, ?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setInt(1, id);
            cst.setString(2, nombres);
            cst.setString(3, apellidos);
            cst.setString(4, correo);
            cst.setString(5, telefono);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error en ClienteDAO al modificar: " + e.getMessage());
            return false;
        }
    }

    // 4. ELIMINAR CLIENTE
    public boolean eliminar(int id) {
        String sql = "{CALL sp_EliminarCliente(?)}";
        try (Connection cn = Conexion.conectar();
             CallableStatement cst = cn.prepareCall(sql)) {
            cst.setInt(1, id);
            return cst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error en ClienteDAO al eliminar: " + e.getMessage());
            return false;
        }
    }
}
