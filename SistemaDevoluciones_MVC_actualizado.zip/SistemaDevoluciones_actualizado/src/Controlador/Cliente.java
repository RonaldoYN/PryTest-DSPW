package Controlador;

import Modelo.ClienteDAO;
import javax.swing.table.DefaultTableModel;

/**
 * Controlador/Clase de Cliente.
 * Se encarga de recibir los datos de la vista y comunicarse con el DAO.
 */
public class Cliente {
    private int idCliente;
    private String nombres;
    private String apellidos;
    private String correo;
    private String telefono;

    private final ClienteDAO clienteDAO;

    public Cliente() {
        this.clienteDAO = new ClienteDAO();
    }

    public Cliente(int idCliente, String nombres, String apellidos, String correo, String telefono) {
        this();
        this.idCliente = idCliente;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
        this.telefono = telefono;
    }

    public DefaultTableModel listar(String criterio) {
        return clienteDAO.listarClientes(criterio == null ? "" : criterio.trim());
    }

    public boolean registrar(String nombres, String apellidos, String correo, String telefono) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
        this.telefono = telefono;
        return clienteDAO.insertar(nombres, apellidos, correo, telefono);
    }

    public boolean registrar() {
        return clienteDAO.insertar(nombres, apellidos, correo, telefono);
    }

    public boolean modificar(int idCliente, String nombres, String apellidos, String correo, String telefono) {
        this.idCliente = idCliente;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
        this.telefono = telefono;
        return clienteDAO.modificar(idCliente, nombres, apellidos, correo, telefono);
    }

    public boolean modificar() {
        return clienteDAO.modificar(idCliente, nombres, apellidos, correo, telefono);
    }

    public boolean eliminar(int idCliente) {
        this.idCliente = idCliente;
        return clienteDAO.eliminar(idCliente);
    }

    public boolean eliminar() {
        return clienteDAO.eliminar(idCliente);
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
