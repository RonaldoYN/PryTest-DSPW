package Controlador;

import Modelo.PersonalDAO;
import javax.swing.table.DefaultTableModel;

/**
 * Controlador/Clase de Personal.
 * Gestiona la lógica entre los formularios y el DAO de personal.
 */
public class Personal {
    private int idPersonal;
    private String nombres;
    private String apellidos;
    private String dni;
    private String correo;
    private String username;
    private String password;
    private String rol;

    private final PersonalDAO personalDAO;

    public Personal() {
        this.personalDAO = new PersonalDAO();
    }

    public Personal(int idPersonal, String nombres, String apellidos, String dni, String correo,
            String username, String password, String rol) {
        this();
        this.idPersonal = idPersonal;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.correo = correo;
        this.username = username;
        this.password = password;
        this.rol = rol;
    }

    public String validarLogin(String username, String password) {
        this.username = username;
        this.password = password;
        return personalDAO.validarLogin(username, password);
    }

    public DefaultTableModel listar(String criterio) {
        return personalDAO.listarPersonal(criterio == null ? "" : criterio.trim());
    }

    public boolean registrar(String nombres, String apellidos, String dni, String correo,
            String username, String password, String rol) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.correo = correo;
        this.username = username;
        this.password = password;
        this.rol = rol;
        return personalDAO.insertar(nombres, apellidos, dni, correo, username, password, rol);
    }

    public boolean registrar() {
        return personalDAO.insertar(nombres, apellidos, dni, correo, username, password, rol);
    }

    public boolean modificar(int idPersonal, String nombres, String apellidos, String dni, String correo,
            String username, String password, String rol) {
        this.idPersonal = idPersonal;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.correo = correo;
        this.username = username;
        this.password = password;
        this.rol = rol;
        return personalDAO.modificar(idPersonal, nombres, apellidos, dni, correo, username, password, rol);
    }

    public boolean modificar() {
        return personalDAO.modificar(idPersonal, nombres, apellidos, dni, correo, username, password, rol);
    }

    public boolean eliminar(int idPersonal) {
        this.idPersonal = idPersonal;
        return personalDAO.eliminar(idPersonal);
    }

    public boolean eliminar() {
        return personalDAO.eliminar(idPersonal);
    }

    public int getIdPersonal() {
        return idPersonal;
    }

    public void setIdPersonal(int idPersonal) {
        this.idPersonal = idPersonal;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
}
