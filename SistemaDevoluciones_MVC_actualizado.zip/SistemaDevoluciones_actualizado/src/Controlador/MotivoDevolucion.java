package Controlador;

/**
 * Clase asociada a la tabla motivo_devolucion.
 */
public class MotivoDevolucion {
    private int idMotivo;
    private String descripcion;

    public MotivoDevolucion() {
    }

    public MotivoDevolucion(int idMotivo, String descripcion) {
        this.idMotivo = idMotivo;
        this.descripcion = descripcion;
    }

    public int getIdMotivo() {
        return idMotivo;
    }

    public void setIdMotivo(int idMotivo) {
        this.idMotivo = idMotivo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
