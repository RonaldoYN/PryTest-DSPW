package Controlador;

import Modelo.ComboItem;
import Modelo.DevolucionDAO;
import java.sql.Timestamp;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 * Controlador/Clase de Devolución.
 * Administra el registro, consulta, seguimiento y reportes de devoluciones.
 */
public class Devolucion {
    private int idDevolucion;
    private Timestamp fechaSolicitud;
    private int idCliente;
    private int idPersonal;
    private int idEstado;
    private int idMotivo;
    private String observacionGeneral;
    private int idPrenda;
    private int cantidad;
    private String observacionDetalle;

    private final DevolucionDAO devolucionDAO;

    public Devolucion() {
        this.devolucionDAO = new DevolucionDAO();
    }

    public Devolucion(int idDevolucion, Timestamp fechaSolicitud, int idCliente, int idPersonal, int idEstado, int idMotivo,
            String observacionGeneral, int idPrenda, int cantidad, String observacionDetalle) {
        this();
        this.idDevolucion = idDevolucion;
        this.fechaSolicitud = fechaSolicitud;
        this.idCliente = idCliente;
        this.idPersonal = idPersonal;
        this.idEstado = idEstado;
        this.idMotivo = idMotivo;
        this.observacionGeneral = observacionGeneral;
        this.idPrenda = idPrenda;
        this.cantidad = cantidad;
        this.observacionDetalle = observacionDetalle;
    }

    public List<ComboItem> cargarClientes() {
        return devolucionDAO.cargarClientes();
    }

    public List<ComboItem> cargarPersonal() {
        return devolucionDAO.cargarPersonal();
    }

    public List<ComboItem> cargarPrendas() {
        return devolucionDAO.cargarPrendas();
    }

    public List<ComboItem> cargarEstados() {
        return devolucionDAO.cargarEstados();
    }

    public List<ComboItem> cargarMotivos() {
        return devolucionDAO.cargarMotivos();
    }

    public boolean registrar(int idCliente, int idPersonal, int idEstado, int idMotivo,
            String observacionGeneral, int idPrenda, int cantidad, String observacionDetalle) {
        this.idCliente = idCliente;
        this.idPersonal = idPersonal;
        this.idEstado = idEstado;
        this.idMotivo = idMotivo;
        this.observacionGeneral = observacionGeneral;
        this.idPrenda = idPrenda;
        this.cantidad = cantidad;
        this.observacionDetalle = observacionDetalle;
        return devolucionDAO.registrarDevolucion(idCliente, idPersonal, idEstado, idMotivo,
                observacionGeneral, idPrenda, cantidad, observacionDetalle);
    }

    public boolean registrar() {
        return devolucionDAO.registrarDevolucion(idCliente, idPersonal, idEstado, idMotivo,
                observacionGeneral, idPrenda, cantidad, observacionDetalle);
    }

    public DefaultTableModel listarGestion(String criterio) {
        return devolucionDAO.listarGestionDevoluciones(criterio == null ? "" : criterio.trim());
    }

    public DefaultTableModel listarDetalle(int idDevolucion) {
        this.idDevolucion = idDevolucion;
        return devolucionDAO.listarDetalleDevolucion(idDevolucion);
    }

    public boolean actualizarEstado(int idDevolucion, int idEstado, String observacionGeneral) {
        this.idDevolucion = idDevolucion;
        this.idEstado = idEstado;
        this.observacionGeneral = observacionGeneral;
        return devolucionDAO.actualizarEstado(idDevolucion, idEstado, observacionGeneral);
    }

    public DefaultTableModel reporteMotivosComunes() {
        return devolucionDAO.reporteMotivosComunes();
    }

    public DefaultTableModel reportePrendasPorCategoria() {
        return devolucionDAO.reportePrendasPorCategoria();
    }

    public int getIdDevolucion() {
        return idDevolucion;
    }

    public void setIdDevolucion(int idDevolucion) {
        this.idDevolucion = idDevolucion;
    }

    public Timestamp getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Timestamp fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdPersonal() {
        return idPersonal;
    }

    public void setIdPersonal(int idPersonal) {
        this.idPersonal = idPersonal;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public int getIdMotivo() {
        return idMotivo;
    }

    public void setIdMotivo(int idMotivo) {
        this.idMotivo = idMotivo;
    }

    public String getObservacionGeneral() {
        return observacionGeneral;
    }

    public void setObservacionGeneral(String observacionGeneral) {
        this.observacionGeneral = observacionGeneral;
    }

    public int getIdPrenda() {
        return idPrenda;
    }

    public void setIdPrenda(int idPrenda) {
        this.idPrenda = idPrenda;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getObservacionDetalle() {
        return observacionDetalle;
    }

    public void setObservacionDetalle(String observacionDetalle) {
        this.observacionDetalle = observacionDetalle;
    }
}
