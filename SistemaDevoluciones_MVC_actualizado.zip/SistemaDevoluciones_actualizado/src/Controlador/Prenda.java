package Controlador;

import Modelo.PrendaDAO;
import javax.swing.table.DefaultTableModel;

/**
 * Controlador/Clase de Prenda.
 * Centraliza la lógica de mantenimiento de prendas antes de llamar al DAO.
 */
public class Prenda {
    private int idPrenda;
    private String nombre;
    private String categoria;
    private String talla;
    private String color;
    private double precio;
    private int stock;

    private final PrendaDAO prendaDAO;

    public Prenda() {
        this.prendaDAO = new PrendaDAO();
    }

    public Prenda(int idPrenda, String nombre, String categoria, String talla, String color, double precio, int stock) {
        this();
        this.idPrenda = idPrenda;
        this.nombre = nombre;
        this.categoria = categoria;
        this.talla = talla;
        this.color = color;
        this.precio = precio;
        this.stock = stock;
    }

    public DefaultTableModel listar(String criterio) {
        return prendaDAO.listarPrendas(criterio == null ? "" : criterio.trim());
    }

    public boolean registrar(String nombre, String categoria, String talla, String color, double precio, int stock) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.talla = talla;
        this.color = color;
        this.precio = precio;
        this.stock = stock;
        return prendaDAO.insertar(nombre, categoria, talla, color, precio, stock);
    }

    public boolean registrar() {
        return prendaDAO.insertar(nombre, categoria, talla, color, precio, stock);
    }

    public boolean modificar(int idPrenda, String nombre, String categoria, String talla, String color, double precio, int stock) {
        this.idPrenda = idPrenda;
        this.nombre = nombre;
        this.categoria = categoria;
        this.talla = talla;
        this.color = color;
        this.precio = precio;
        this.stock = stock;
        return prendaDAO.modificar(idPrenda, nombre, categoria, talla, color, precio, stock);
    }

    public boolean modificar() {
        return prendaDAO.modificar(idPrenda, nombre, categoria, talla, color, precio, stock);
    }

    public boolean eliminar(int idPrenda) {
        this.idPrenda = idPrenda;
        return prendaDAO.eliminar(idPrenda);
    }

    public boolean eliminar() {
        return prendaDAO.eliminar(idPrenda);
    }

    public int getIdPrenda() {
        return idPrenda;
    }

    public void setIdPrenda(int idPrenda) {
        this.idPrenda = idPrenda;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
