package Controlador;

/**
 * Clase asociada a la tabla detalle_devolucion.
 */
public class DetalleDevolucion {
    private int idDetalle;
    private int idDevolucion;
    private int idPrenda;
    private int cantidad;
    private String observacion;

    public DetalleDevolucion() {
    }

    public DetalleDevolucion(int idDetalle, int idDevolucion, int idPrenda, int cantidad, String observacion) {
        this.idDetalle = idDetalle;
        this.idDevolucion = idDevolucion;
        this.idPrenda = idPrenda;
        this.cantidad = cantidad;
        this.observacion = observacion;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public int getIdDevolucion() {
        return idDevolucion;
    }

    public void setIdDevolucion(int idDevolucion) {
        this.idDevolucion = idDevolucion;
    }

    public int getIdPrenda() {
        return idPrenda;
    }

    public void setIdPrenda(int idPrenda) {
        this.idPrenda = idPrenda;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
}
