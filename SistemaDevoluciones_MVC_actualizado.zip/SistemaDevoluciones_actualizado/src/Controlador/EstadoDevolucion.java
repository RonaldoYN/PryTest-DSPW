package Controlador;

/**
 * Clase asociada a la tabla estado_devolucion.
 */
public class EstadoDevolucion {
    private int idEstado;
    private String nombreEstado;

    public EstadoDevolucion() {
    }

    public EstadoDevolucion(int idEstado, String nombreEstado) {
        this.idEstado = idEstado;
        this.nombreEstado = nombreEstado;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public String getNombreEstado() {
        return nombreEstado;
    }

    public void setNombreEstado(String nombreEstado) {
        this.nombreEstado = nombreEstado;
    }
}
