package Vista;

import Controlador.Devolucion;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class frmReporte extends JFrame {

    private final Devolucion devolucion = new Devolucion();
    private JTable tablaMotivos;
    private JTable tablaCategorias;

    public frmReporte() {
        initComponents();
        setTitle("Reportes de Devoluciones");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cargarReportes();
    }

    private void initComponents() {
        setLayout(new BorderLayout(8, 8));

        JLabel lblTitulo = new JLabel("REPORTES DE DEVOLUCIONES", JLabel.CENTER);
        lblTitulo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22));
        add(lblTitulo, BorderLayout.NORTH);

        tablaMotivos = new JTable();
        tablaCategorias = new JTable();

        JPanel panelTablas = new JPanel(new GridLayout(1, 2, 10, 10));
        JPanel panelMotivos = new JPanel(new BorderLayout());
        panelMotivos.setBorder(BorderFactory.createTitledBorder("Motivos más comunes"));
        panelMotivos.add(new JScrollPane(tablaMotivos), BorderLayout.CENTER);

        JPanel panelCategorias = new JPanel(new BorderLayout());
        panelCategorias.setBorder(BorderFactory.createTitledBorder("Prendas devueltas por categoría"));
        panelCategorias.add(new JScrollPane(tablaCategorias), BorderLayout.CENTER);

        panelTablas.add(panelMotivos);
        panelTablas.add(panelCategorias);
        add(panelTablas, BorderLayout.CENTER);

        JButton btnActualizar = new JButton("Actualizar reportes");
        btnActualizar.addActionListener(e -> cargarReportes());
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnActualizar);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarReportes() {
        tablaMotivos.setModel(devolucion.reporteMotivosComunes());
        tablaCategorias.setModel(devolucion.reportePrendasPorCategoria());
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frmReporte().setVisible(true));
    }
}
