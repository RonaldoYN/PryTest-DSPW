package Vista;

import Controlador.Devolucion;
import Modelo.ComboItem;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class frmRegistroDevolucion extends JFrame {

    private final Devolucion devolucion = new Devolucion();

    private JComboBox<ComboItem> cboCliente;
    private JComboBox<ComboItem> cboPersonal;
    private JComboBox<ComboItem> cboMotivo;
    private JComboBox<ComboItem> cboEstado;
    private JComboBox<ComboItem> cboPrenda;
    private JTextField txtCantidad;
    private JTextArea txtObservacionGeneral;
    private JTextArea txtObservacionDetalle;
    private JTable tablaDevoluciones;

    public frmRegistroDevolucion() {
        initComponents();
        setTitle("Registro de Devolución");
        setSize(1000, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cargarCombos();
        mostrarDevoluciones();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JLabel lblTitulo = new JLabel("REGISTRO DE DEVOLUCIÓN", JLabel.CENTER);
        lblTitulo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos de la devolución"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        cboCliente = new JComboBox<>();
        cboPersonal = new JComboBox<>();
        cboMotivo = new JComboBox<>();
        cboEstado = new JComboBox<>();
        cboPrenda = new JComboBox<>();
        txtCantidad = new JTextField("1");
        txtObservacionGeneral = new JTextArea(3, 25);
        txtObservacionDetalle = new JTextArea(3, 25);

        agregarCampo(panelFormulario, gbc, 0, "Cliente:", cboCliente);
        agregarCampo(panelFormulario, gbc, 1, "Personal que atiende:", cboPersonal);
        agregarCampo(panelFormulario, gbc, 2, "Motivo:", cboMotivo);
        agregarCampo(panelFormulario, gbc, 3, "Estado inicial:", cboEstado);
        agregarCampo(panelFormulario, gbc, 4, "Prenda:", cboPrenda);
        agregarCampo(panelFormulario, gbc, 5, "Cantidad:", txtCantidad);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.weightx = 0;
        panelFormulario.add(new JLabel("Observación general:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        panelFormulario.add(new JScrollPane(txtObservacionGeneral), gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.weightx = 0;
        panelFormulario.add(new JLabel("Observación detalle:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        panelFormulario.add(new JScrollPane(txtObservacionDetalle), gbc);

        JButton btnRegistrar = new JButton("Registrar devolución");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnRefrescar = new JButton("Refrescar tabla");

        btnRegistrar.addActionListener(e -> registrarDevolucion());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnRefrescar.addActionListener(e -> mostrarDevoluciones());

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnRefrescar);

        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.add(panelFormulario, BorderLayout.CENTER);
        panelIzquierdo.add(panelBotones, BorderLayout.SOUTH);
        add(panelIzquierdo, BorderLayout.WEST);

        tablaDevoluciones = new JTable();
        add(new JScrollPane(tablaDevoluciones), BorderLayout.CENTER);
    }

    private void agregarCampo(JPanel panel, GridBagConstraints gbc, int fila, String etiqueta, java.awt.Component componente) {
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.weightx = 0;
        panel.add(new JLabel(etiqueta), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(componente, gbc);
    }

    private void cargarCombos() {
        cargarCombo(cboCliente, devolucion.cargarClientes());
        cargarCombo(cboPersonal, devolucion.cargarPersonal());
        cargarCombo(cboMotivo, devolucion.cargarMotivos());
        cargarCombo(cboEstado, devolucion.cargarEstados());
        cargarCombo(cboPrenda, devolucion.cargarPrendas());
        seleccionarPendiente();
    }

    private void cargarCombo(JComboBox<ComboItem> combo, java.util.List<ComboItem> datos) {
        combo.removeAllItems();
        for (ComboItem item : datos) {
            combo.addItem(item);
        }
    }

    private void seleccionarPendiente() {
        for (int i = 0; i < cboEstado.getItemCount(); i++) {
            if (cboEstado.getItemAt(i).getTexto().equalsIgnoreCase("Pendiente")) {
                cboEstado.setSelectedIndex(i);
                break;
            }
        }
    }

    private void registrarDevolucion() {
        if (cboCliente.getSelectedItem() == null || cboPersonal.getSelectedItem() == null
                || cboMotivo.getSelectedItem() == null || cboEstado.getSelectedItem() == null
                || cboPrenda.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Debe cargar y seleccionar cliente, personal, motivo, estado y prenda.");
            return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor que cero.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
            return;
        }

        ComboItem cliente = (ComboItem) cboCliente.getSelectedItem();
        ComboItem personal = (ComboItem) cboPersonal.getSelectedItem();
        ComboItem motivo = (ComboItem) cboMotivo.getSelectedItem();
        ComboItem estado = (ComboItem) cboEstado.getSelectedItem();
        ComboItem prenda = (ComboItem) cboPrenda.getSelectedItem();

        boolean exito = devolucion.registrar(
                cliente.getId(),
                personal.getId(),
                estado.getId(),
                motivo.getId(),
                txtObservacionGeneral.getText().trim(),
                prenda.getId(),
                cantidad,
                txtObservacionDetalle.getText().trim()
        );

        if (exito) {
            JOptionPane.showMessageDialog(this, "Devolución registrada correctamente.");
            limpiarCampos();
            mostrarDevoluciones();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo registrar la devolución.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        if (cboCliente.getItemCount() > 0) cboCliente.setSelectedIndex(0);
        if (cboPersonal.getItemCount() > 0) cboPersonal.setSelectedIndex(0);
        if (cboMotivo.getItemCount() > 0) cboMotivo.setSelectedIndex(0);
        if (cboPrenda.getItemCount() > 0) cboPrenda.setSelectedIndex(0);
        seleccionarPendiente();
        txtCantidad.setText("1");
        txtObservacionGeneral.setText("");
        txtObservacionDetalle.setText("");
    }

    private void mostrarDevoluciones() {
        tablaDevoluciones.setModel(devolucion.listarGestion(""));
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frmRegistroDevolucion().setVisible(true));
    }
}
