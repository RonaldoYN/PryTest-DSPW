package Vista;

import Controlador.Devolucion;
import Modelo.ComboItem;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class frmGestionDevolucion extends JFrame {

    private final Devolucion devolucion = new Devolucion();

    private JTable tablaDevoluciones;
    private JTable tablaDetalle;
    private JTextField txtBuscar;
    private JTextField txtIdDevolucion;
    private JComboBox<ComboItem> cboEstado;
    private JTextArea txtObservacion;

    public frmGestionDevolucion() {
        initComponents();
        setTitle("Gestión de Devoluciones");
        setSize(1100, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cargarEstados();
        mostrarDevoluciones("");
    }

    private void initComponents() {
        setLayout(new BorderLayout(8, 8));

        JLabel lblTitulo = new JLabel("GESTIÓN DE DEVOLUCIONES", JLabel.CENTER);
        lblTitulo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelSuperior = new JPanel(new BorderLayout(8, 8));
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));
        txtBuscar = new JTextField();
        JButton btnBuscar = new JButton("Buscar");
        JButton btnMostrarTodo = new JButton("Mostrar todo");

        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.add(new JLabel("Buscar por cliente, motivo, estado o ID:"), BorderLayout.WEST);
        panelBusqueda.add(txtBuscar, BorderLayout.CENTER);
        JPanel botonesBusqueda = new JPanel();
        botonesBusqueda.add(btnBuscar);
        botonesBusqueda.add(btnMostrarTodo);
        panelBusqueda.add(botonesBusqueda, BorderLayout.EAST);
        panelSuperior.add(panelBusqueda, BorderLayout.NORTH);
        add(panelSuperior, BorderLayout.NORTH);

        tablaDevoluciones = new JTable();
        tablaDevoluciones.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seleccionarDevolucion();
            }
        });

        tablaDetalle = new JTable();
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                new JScrollPane(tablaDevoluciones), new JScrollPane(tablaDetalle));
        splitPane.setResizeWeight(0.65);
        add(splitPane, BorderLayout.CENTER);

        JPanel panelEdicion = new JPanel(new GridBagLayout());
        panelEdicion.setBorder(BorderFactory.createTitledBorder("Actualizar estado"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtIdDevolucion = new JTextField(8);
        txtIdDevolucion.setEditable(false);
        cboEstado = new JComboBox<>();
        txtObservacion = new JTextArea(3, 28);
        JButton btnActualizar = new JButton("Actualizar estado");

        gbc.gridx = 0; gbc.gridy = 0; panelEdicion.add(new JLabel("ID devolución:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; panelEdicion.add(txtIdDevolucion, gbc);
        gbc.gridx = 2; gbc.gridy = 0; panelEdicion.add(new JLabel("Nuevo estado:"), gbc);
        gbc.gridx = 3; gbc.gridy = 0; panelEdicion.add(cboEstado, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panelEdicion.add(new JLabel("Observación:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 3; panelEdicion.add(new JScrollPane(txtObservacion), gbc);
        gbc.gridx = 3; gbc.gridy = 2; gbc.gridwidth = 1; panelEdicion.add(btnActualizar, gbc);

        add(panelEdicion, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e -> mostrarDevoluciones(txtBuscar.getText().trim()));
        btnMostrarTodo.addActionListener(e -> {
            txtBuscar.setText("");
            mostrarDevoluciones("");
        });
        btnActualizar.addActionListener(e -> actualizarEstado());
    }

    private void cargarEstados() {
        cboEstado.removeAllItems();
        for (ComboItem item : devolucion.cargarEstados()) {
            cboEstado.addItem(item);
        }
    }

    private void mostrarDevoluciones(String criterio) {
        tablaDevoluciones.setModel(devolucion.listarGestion(criterio));
        tablaDetalle.setModel(new javax.swing.table.DefaultTableModel());
    }

    private void seleccionarDevolucion() {
        int fila = tablaDevoluciones.getSelectedRow();
        if (fila < 0) {
            return;
        }

        int id = Integer.parseInt(tablaDevoluciones.getValueAt(fila, 0).toString());
        txtIdDevolucion.setText(String.valueOf(id));
        txtObservacion.setText(tablaDevoluciones.getValueAt(fila, 6) == null ? "" : tablaDevoluciones.getValueAt(fila, 6).toString());
        seleccionarEstadoPorTexto(tablaDevoluciones.getValueAt(fila, 5).toString());
        tablaDetalle.setModel(devolucion.listarDetalle(id));
    }

    private void seleccionarEstadoPorTexto(String estado) {
        for (int i = 0; i < cboEstado.getItemCount(); i++) {
            if (cboEstado.getItemAt(i).getTexto().equalsIgnoreCase(estado)) {
                cboEstado.setSelectedIndex(i);
                break;
            }
        }
    }

    private void actualizarEstado() {
        if (txtIdDevolucion.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seleccione una devolución de la tabla.");
            return;
        }

        ComboItem estado = (ComboItem) cboEstado.getSelectedItem();
        if (estado == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un estado.");
            return;
        }

        int idDevolucion = Integer.parseInt(txtIdDevolucion.getText().trim());
        boolean exito = devolucion.actualizarEstado(idDevolucion, estado.getId(), txtObservacion.getText().trim());

        if (exito) {
            JOptionPane.showMessageDialog(this, "Estado actualizado correctamente.");
            mostrarDevoluciones(txtBuscar.getText().trim());
            txtIdDevolucion.setText("");
            txtObservacion.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo actualizar el estado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frmGestionDevolucion().setVisible(true));
    }
}
